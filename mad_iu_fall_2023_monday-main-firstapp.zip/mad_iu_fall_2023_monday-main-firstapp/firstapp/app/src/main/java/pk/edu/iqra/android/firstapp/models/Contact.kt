package pk.edu.iqra.android.firstapp.models

data class Contact(val id:String, val name:String,val mobileNumber:String)

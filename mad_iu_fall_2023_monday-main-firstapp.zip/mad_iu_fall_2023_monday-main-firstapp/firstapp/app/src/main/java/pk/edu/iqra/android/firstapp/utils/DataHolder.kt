package pk.edu.iqra.android.firstapp.utils

import pk.edu.iqra.android.firstapp.models.BUser

object DataHolder {
    lateinit var bUser:BUser
}